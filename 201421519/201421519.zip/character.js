var util = require('util');
var EventEmitter = require('events').EventEmitter;


var Character = function(name, level){
    var self = this;
    this.item = new Array(); //처음 생성시에만 변수 선언
    this.name = name;
    this.level = level;
    
    this.on('addItem',function(){// 이벤트 발생시 item 을 변경
        this.item = item; // 

    });
}

//function Character(item)
////    this.name = name;
////    this.level = level;
//
////    this.item = new Array(); //함수 생성시 변수 초기화 ..? 되려나
//    
//    this.on('addItem',function(){// 이벤트 발생시 item 을 변경
//        this.item = item; // 
//
//    });
//};
//
//
//
Character.prototype.addItem = function(name, level){
    
}// 사용법 Character.??(값 전달.)


util.inherits(Character, EventEmitter);
module.exports = Character; // 모듈 내보내기.