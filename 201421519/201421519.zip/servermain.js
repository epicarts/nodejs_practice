var http = require('http');
var express = require('express');
var static = require('serve-static');
var path = require('path');
var bodyParser = require('body-parser');
var Character = require('./character');
var app = express();
var ch;

app.use('/public',static(path.join(__dirname, 'html')));
app.use(bodyParser.urlencoded({extended:false}));
app.use(bodyParser.json());

app.use(function(req, res, next){
    
    var sel = req.query.sel;
    var parname = req.body.inputN;
    var parlevel = req.body.inputL;
    
    console.log(parname, parlevel);
    if (sel == 'Create'){
        res.redirect('/public/create.html');
    };
    
    if (sel == 'Add Item'){
        res.redirect('/public/add.html');
    };
    
    if (sel == 'View'){
        res.write('<h1>Character Name:</h1>' );
        res.write('<h1>Character Level:</h1>' );
        res.write('<h1>Item list:</h1>' );
        res.end();
        res.redirect('/');
    };
    next();
});


//두번쨰 미들 웨어 작성
app.use(function(req, res, next){
    var parname = req.body.inputN;
    var parlevel = req.body.inputL;
    
    if (parname && parlevel){
        console.log(parname, parlevel);
        ch = new Character(parname, parlevel);
    };
    res.end();
});



http.createServer(app).listen(3300, function(){
    console.log("express server start......");
});